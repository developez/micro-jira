import{l as o,d as r}from"../chunks/KuyuNg1V.js";export{o as load_css,r as start};
